// ── User & Auth ──────────────────────────────────────
export interface User {
  id: string
  email: string
  github_username: string | null
  github_avatar: string | null
  plan: 'free' | 'pro' | 'enterprise'
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  scans_this_month: number
  created_at: string
}

// ── GitHub ───────────────────────────────────────────
export interface GithubRepo {
  id: string
  user_id: string
  github_repo_id: number
  owner: string
  name: string
  full_name: string
  private: boolean
  default_branch: string
  last_scanned_at: string | null
  installation_id: number | null
  created_at: string
}

// ── Scans ────────────────────────────────────────────
export type ScanStatus = 'pending' | 'scanning' | 'complete' | 'failed'
export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'

export interface Scan {
  id: string
  user_id: string
  repo_id: string | null
  repo_full_name: string | null
  commit_sha: string | null
  branch: string | null
  status: ScanStatus
  total_findings: number
  critical_count: number
  high_count: number
  medium_count: number
  low_count: number
  risk_score: number
  hndl_max: number
  files_scanned: number
  triggered_by: 'manual' | 'webhook' | 'api'
  created_at: string
  completed_at: string | null
}

export interface Finding {
  id: string
  scan_id: string
  file_path: string
  line_number: number
  line_text: string
  algorithm: string
  severity: Severity
  hndl_years: number
  qday_risk: string
  attack_description: string
  fix_description: string
  diff_vulnerable: string
  diff_fix: string
  ai_fix: string | null
  resolved: boolean
  resolved_at: string | null
  created_at: string
}

// ── Billing ──────────────────────────────────────────
export interface PlanLimits {
  scans_per_month: number   // -1 = unlimited
  repos: number             // -1 = unlimited
  ai_messages: number       // -1 = unlimited
  zip_max_mb: number
  github_integration: boolean
  ci_action: boolean
  compliance_reports: boolean
  slack_integration: boolean
  sso: boolean
}

export const PLAN_LIMITS: Record<User['plan'], PlanLimits> = {
  free: {
    scans_per_month: 5,
    repos: 1,
    ai_messages: 10,
    zip_max_mb: 10,
    github_integration: false,
    ci_action: false,
    compliance_reports: false,
    slack_integration: false,
    sso: false,
  },
  pro: {
    scans_per_month: -1,
    repos: -1,
    ai_messages: -1,
    zip_max_mb: 100,
    github_integration: true,
    ci_action: true,
    compliance_reports: false,
    slack_integration: false,
    sso: false,
  },
  enterprise: {
    scans_per_month: -1,
    repos: -1,
    ai_messages: -1,
    zip_max_mb: 500,
    github_integration: true,
    ci_action: true,
    compliance_reports: true,
    slack_integration: true,
    sso: true,
  },
}

// ── Scan Engine ──────────────────────────────────────
export interface VulnPattern {
  lang: string[]
  sev: Severity
  name: string
  pattern: RegExp
  hndl: number
  qdayRisk: string
  attack: string
  fix: string
  diffVuln: string
  diffFix: string
}

export interface ScanFinding {
  lineNum: number
  lineText: string
  filePath?: string
  vuln: VulnPattern
}

export interface FileScanResult {
  path: string
  lang: string
  lineCount: number
  findings: ScanFinding[]
}

// ── API responses ────────────────────────────────────
export interface ApiResponse<T = unknown> {
  data?: T
  error?: string
  message?: string
}
