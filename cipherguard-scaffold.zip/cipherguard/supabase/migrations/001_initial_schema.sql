-- ─────────────────────────────────────────────────────────────
-- CipherGuard — Complete Database Schema
-- Run: supabase db push
-- ─────────────────────────────────────────────────────────────

-- Enable extensions
create extension if not exists "uuid-ossp";
create extension if not exists "pg_cron";

-- ── USERS ────────────────────────────────────────────────────
create table public.users (
  id                    uuid references auth.users(id) on delete cascade primary key,
  email                 text not null unique,
  github_username       text,
  github_avatar         text,
  github_installation_id bigint,
  plan                  text not null default 'free' check (plan in ('free','pro','enterprise')),
  stripe_customer_id    text unique,
  stripe_subscription_id text unique,
  stripe_subscription_status text,
  scans_this_month      int not null default 0,
  scans_month_reset_at  timestamptz not null default date_trunc('month', now()),
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

-- RLS
alter table public.users enable row level security;
create policy "users can read own row" on public.users for select using (auth.uid() = id);
create policy "users can update own row" on public.users for update using (auth.uid() = id);

-- ── REPOS ────────────────────────────────────────────────────
create table public.repos (
  id                uuid primary key default uuid_generate_v4(),
  user_id           uuid not null references public.users(id) on delete cascade,
  github_repo_id    bigint not null,
  owner             text not null,
  name              text not null,
  full_name         text not null,
  private           boolean not null default false,
  default_branch    text not null default 'main',
  installation_id   bigint,
  webhook_active    boolean not null default false,
  last_scanned_at   timestamptz,
  created_at        timestamptz not null default now(),
  unique(user_id, github_repo_id)
);

alter table public.repos enable row level security;
create policy "users can crud own repos" on public.repos for all using (auth.uid() = user_id);
create index repos_user_id_idx on public.repos(user_id);

-- ── SCANS ────────────────────────────────────────────────────
create table public.scans (
  id                uuid primary key default uuid_generate_v4(),
  user_id           uuid not null references public.users(id) on delete cascade,
  repo_id           uuid references public.repos(id) on delete set null,
  repo_full_name    text,
  commit_sha        text,
  branch            text,
  status            text not null default 'pending' check (status in ('pending','scanning','complete','failed')),
  total_findings    int not null default 0,
  critical_count    int not null default 0,
  high_count        int not null default 0,
  medium_count      int not null default 0,
  low_count         int not null default 0,
  risk_score        int not null default 0,
  hndl_max          int not null default 0,
  files_scanned     int not null default 0,
  triggered_by      text not null default 'manual' check (triggered_by in ('manual','webhook','api')),
  error_message     text,
  created_at        timestamptz not null default now(),
  completed_at      timestamptz
);

alter table public.scans enable row level security;
create policy "users can crud own scans" on public.scans for all using (auth.uid() = user_id);
create index scans_user_id_idx on public.scans(user_id);
create index scans_repo_id_idx on public.scans(repo_id);
create index scans_created_at_idx on public.scans(created_at desc);

-- ── FINDINGS ─────────────────────────────────────────────────
create table public.findings (
  id                uuid primary key default uuid_generate_v4(),
  scan_id           uuid not null references public.scans(id) on delete cascade,
  user_id           uuid not null references public.users(id) on delete cascade,
  file_path         text not null,
  line_number       int not null,
  line_text         text,
  algorithm         text not null,
  severity          text not null check (severity in ('CRITICAL','HIGH','MEDIUM','LOW')),
  hndl_years        int not null,
  qday_risk         text not null,
  attack_description text not null,
  fix_description   text not null,
  diff_vulnerable   text,
  diff_fix          text,
  ai_fix            text,
  resolved          boolean not null default false,
  resolved_at       timestamptz,
  resolved_by       uuid references public.users(id),
  created_at        timestamptz not null default now()
);

alter table public.findings enable row level security;
create policy "users can read own findings" on public.findings for select using (auth.uid() = user_id);
create policy "users can update own findings" on public.findings for update using (auth.uid() = user_id);
create index findings_scan_id_idx on public.findings(scan_id);
create index findings_user_id_idx on public.findings(user_id);
create index findings_severity_idx on public.findings(severity);

-- ── SCAN USAGE QUOTA FUNCTION ─────────────────────────────────
create or replace function public.increment_scan_count(p_user_id uuid)
returns void language plpgsql security definer as $$
declare
  v_reset_at timestamptz;
begin
  select scans_month_reset_at into v_reset_at from public.users where id = p_user_id;
  -- Reset counter if we're in a new month
  if date_trunc('month', now()) > date_trunc('month', v_reset_at) then
    update public.users
    set scans_this_month = 1,
        scans_month_reset_at = date_trunc('month', now()),
        updated_at = now()
    where id = p_user_id;
  else
    update public.users
    set scans_this_month = scans_this_month + 1,
        updated_at = now()
    where id = p_user_id;
  end if;
end;
$$;

-- ── CHECK SCAN QUOTA FUNCTION ─────────────────────────────────
create or replace function public.can_scan(p_user_id uuid)
returns boolean language plpgsql security definer as $$
declare
  v_plan text;
  v_count int;
  v_reset_at timestamptz;
begin
  select plan, scans_this_month, scans_month_reset_at
  into v_plan, v_count, v_reset_at
  from public.users where id = p_user_id;

  -- Reset if new month
  if date_trunc('month', now()) > date_trunc('month', v_reset_at) then
    return true;
  end if;

  -- Pro and Enterprise have unlimited scans
  if v_plan in ('pro', 'enterprise') then return true; end if;

  -- Free tier: 5 scans per month
  return v_count < 5;
end;
$$;

-- ── UPDATED_AT TRIGGER ─────────────────────────────────────────
create or replace function public.handle_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger users_updated_at before update on public.users
  for each row execute function public.handle_updated_at();

-- ── NEW USER TRIGGER ──────────────────────────────────────────
-- Auto-create user row when someone signs up via Supabase Auth
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.users (id, email, github_username, github_avatar)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'user_name',
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
