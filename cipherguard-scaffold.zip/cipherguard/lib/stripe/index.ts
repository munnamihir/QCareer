// lib/stripe/index.ts
import Stripe from 'stripe'
import { createServiceClient } from '@/lib/supabase/server'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
  typescript: true,
})

export const PLANS = {
  pro: {
    priceId: process.env.STRIPE_PRO_PRICE_ID!,
    name: 'Pro',
    price: 49,
    interval: 'month' as const,
  },
  enterprise: {
    priceId: process.env.STRIPE_ENTERPRISE_PRICE_ID!,
    name: 'Enterprise',
    price: null, // custom
    interval: 'month' as const,
  },
}

// Create or retrieve Stripe customer for a user
export async function getOrCreateStripeCustomer(userId: string, email: string): Promise<string> {
  const supabase = createServiceClient()
  const { data: user } = await supabase
    .from('users').select('stripe_customer_id').eq('id', userId).single()

  if (user?.stripe_customer_id) return user.stripe_customer_id

  const customer = await stripe.customers.create({
    email,
    metadata: { supabase_user_id: userId },
  })

  await supabase.from('users')
    .update({ stripe_customer_id: customer.id })
    .eq('id', userId)

  return customer.id
}

// Create Stripe Checkout session
export async function createCheckoutSession(params: {
  userId: string
  email: string
  plan: 'pro' | 'enterprise'
  returnUrl: string
}): Promise<string> {
  const customerId = await getOrCreateStripeCustomer(params.userId, params.email)
  const planConfig = PLANS[params.plan]

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [{ price: planConfig.priceId, quantity: 1 }],
    success_url: `${params.returnUrl}?session_id={CHECKOUT_SESSION_ID}&upgraded=true`,
    cancel_url: `${params.returnUrl}?cancelled=true`,
    metadata: { supabase_user_id: params.userId, plan: params.plan },
    subscription_data: {
      metadata: { supabase_user_id: params.userId, plan: params.plan },
    },
    allow_promotion_codes: true,
  })

  return session.url!
}

// Create billing portal session for plan management
export async function createPortalSession(customerId: string, returnUrl: string): Promise<string> {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  })
  return session.url
}

// Handle webhook events from Stripe
export async function handleStripeWebhook(event: Stripe.Event): Promise<void> {
  const supabase = createServiceClient()

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session
      const userId = session.metadata?.supabase_user_id
      const plan = session.metadata?.plan as 'pro' | 'enterprise' | undefined

      if (!userId || !plan) break

      await supabase.from('users').update({
        plan,
        stripe_subscription_id: session.subscription as string,
        stripe_subscription_status: 'active',
      }).eq('id', userId)
      break
    }

    case 'customer.subscription.updated': {
      const sub = event.data.object as Stripe.Subscription
      const userId = sub.metadata?.supabase_user_id
      if (!userId) break

      const plan = sub.metadata?.plan as 'pro' | 'enterprise' | undefined
      const status = sub.status

      await supabase.from('users').update({
        plan: status === 'active' ? plan : 'free',
        stripe_subscription_status: status,
      }).eq('id', userId)
      break
    }

    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription
      const userId = sub.metadata?.supabase_user_id
      if (!userId) break

      await supabase.from('users').update({
        plan: 'free',
        stripe_subscription_id: null,
        stripe_subscription_status: 'cancelled',
      }).eq('id', userId)
      break
    }
  }
}
