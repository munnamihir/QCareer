// lib/scan/engine.ts
// Core scan engine — runs in Node.js (server) or browser
import type { VulnPattern, ScanFinding, FileScanResult } from '@/types'

export const VULN_DB: VulnPattern[] = [
  // ── JavaScript / Node.js ─────────────────────────────
  { lang:['js','auto'], sev:'CRITICAL', name:'RSA-OAEP Key Generation',
    pattern:/generateKey\s*\(\s*\{[^}]*name\s*:\s*['"]RSA-OAEP['"]/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Shor's algorithm factors RSA in polynomial time on a CRQC. Keys generated today are harvestable via HNDL.",
    fix:'Replace with ML-KEM-768 (FIPS 203) via @noble/post-quantum.',
    diffVuln:"const kp = await crypto.subtle.generateKey({ name: 'RSA-OAEP', modulusLength: 2048 }, true, ['encrypt','decrypt'])",
    diffFix:"import { ml_kem768 } from '@noble/post-quantum/ml-kem'\nconst { publicKey, secretKey } = ml_kem768.keygen()" },

  { lang:['js','auto'], sev:'CRITICAL', name:'ECDH Key Agreement',
    pattern:/generateKey\s*\(\s*\{[^}]*name\s*:\s*['"]ECDH['"]/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Shor's algorithm solves ECDLP. P-256, P-384, P-521 all broken by quantum.",
    fix:'Replace with ML-KEM-768 (FIPS 203) for key agreement.',
    diffVuln:"await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey'])",
    diffFix:"import { ml_kem768 } from '@noble/post-quantum/ml-kem'\nconst { publicKey, secretKey } = ml_kem768.keygen()" },

  { lang:['js','auto'], sev:'HIGH', name:'ECDSA Signature',
    pattern:/generateKey\s*\(\s*\{[^}]*name\s*:\s*['"]ECDSA['"]/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"ECDSA broken by Shor's. Long-lived signatures on documents and certs are at risk.",
    fix:'Replace with ML-DSA-65 (FIPS 204).',
    diffVuln:"await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign','verify'])",
    diffFix:"import { ml_dsa65 } from '@noble/post-quantum/ml-dsa'\nconst { publicKey, secretKey } = ml_dsa65.keygen()" },

  { lang:['js','auto'], sev:'HIGH', name:'JWT RS256/RS512',
    pattern:/algorithm\s*:\s*['"]RS(256|384|512)['"]/gi,
    hndl:10, qdayRisk:'HIGH',
    attack:"RSA JWTs: quantum computer derives private key and forges any token.",
    fix:'Use HS256 for short-lived tokens. ML-DSA-65 for long-lived.',
    diffVuln:"jwt.sign(payload, privateKey, { algorithm: 'RS256' })",
    diffFix:"jwt.sign(payload, process.env.JWT_SECRET, { algorithm: 'HS256' })" },

  { lang:['js','auto'], sev:'MEDIUM', name:'SHA-1 Hash',
    pattern:/['"]SHA-1['"]/gi,
    hndl:5, qdayRisk:'MEDIUM',
    attack:"SHA-1 classically broken. Grover's reduces quantum security to ~40-bit.",
    fix:'Use SHA-256 (128-bit quantum security via Grover).',
    diffVuln:"crypto.subtle.digest('SHA-1', data)",
    diffFix:"crypto.subtle.digest('SHA-256', data)" },

  { lang:['js','auto'], sev:'HIGH', name:'Node.js crypto.generateKeyPair RSA',
    pattern:/generateKeyPair\s*\(\s*['"]rsa['"]/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"RSA keypairs broken by Shor's. HNDL: adversaries collect encrypted traffic today.",
    fix:'Use @noble/post-quantum ml_kem768 for encryption.',
    diffVuln:"crypto.generateKeyPair('rsa', { modulusLength: 2048 }, callback)",
    diffFix:"import { ml_kem768 } from '@noble/post-quantum/ml-kem'\nconst { publicKey, secretKey } = ml_kem768.keygen()" },

  // ── Python ───────────────────────────────────────────
  { lang:['py','auto'], sev:'CRITICAL', name:'Python RSA Key Generation',
    pattern:/rsa\.generate_private_key|generate_private_key\s*\(\s*public_exponent/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Python cryptography RSA broken by Shor's algorithm on a CRQC.",
    fix:'Use liboqs-python: oqs.KeyEncapsulation("ML-KEM-768").',
    diffVuln:"private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)",
    diffFix:"import oqs\nkem = oqs.KeyEncapsulation('ML-KEM-768')\npublic_key = kem.generate_keypair()" },

  { lang:['py','auto'], sev:'CRITICAL', name:'Python ECDH / EC Key',
    pattern:/ec\.generate_private_key|EllipticCurvePrivateKey/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"ECDH/ECDSA over P-256, P-384 — all broken by quantum Shor's.",
    fix:'Use liboqs-python ML-KEM-768 for key exchange.',
    diffVuln:"private_key = ec.generate_private_key(ec.SECP256R1())",
    diffFix:"import oqs\nkem = oqs.KeyEncapsulation('ML-KEM-768')\npublic_key = kem.generate_keypair()" },

  { lang:['py','auto'], sev:'MEDIUM', name:'Python hashlib MD5',
    pattern:/hashlib\.md5|md5\(\)/gi,
    hndl:2, qdayRisk:'MEDIUM',
    attack:"MD5 classically broken. Grover's provides additional speedup.",
    fix:'Use hashlib.sha256() or hashlib.sha3_256().',
    diffVuln:"h = hashlib.md5(data).hexdigest()",
    diffFix:"h = hashlib.sha256(data).hexdigest()" },

  { lang:['py','auto'], sev:'MEDIUM', name:'Python hashlib SHA-1',
    pattern:/hashlib\.sha1/gi,
    hndl:3, qdayRisk:'MEDIUM',
    attack:"SHA-1 classically broken. Grover's reduces to ~40-bit quantum security.",
    fix:'Replace with hashlib.sha256().',
    diffVuln:"h = hashlib.sha1(data).hexdigest()",
    diffFix:"h = hashlib.sha256(data).hexdigest()" },

  // ── Java ─────────────────────────────────────────────
  { lang:['java','auto'], sev:'CRITICAL', name:'Java RSA KeyPairGenerator',
    pattern:/KeyPairGenerator\.getInstance\s*\(\s*['"]RSA['"]/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Java RSA broken by Shor's. Any keypair generated today is future-harvestable.",
    fix:'Use BouncyCastle 1.78+ MLKEMKeyPairGenerator.',
    diffVuln:'KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");\nkpg.initialize(2048);',
    diffFix:'MLKEMKeyPairGenerator gen = new MLKEMKeyPairGenerator();\ngen.init(new MLKEMKeyGenerationParameters(new SecureRandom(), MLKEMParameters.ml_kem_768));' },

  { lang:['java','auto'], sev:'CRITICAL', name:'Java EC KeyPairGenerator',
    pattern:/KeyPairGenerator\.getInstance\s*\(\s*['"]EC['"]/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Java EC (ECDH/ECDSA) over P-256 — zero quantum resistance.",
    fix:'Migrate to ML-KEM-768 or ML-DSA-65 via BouncyCastle 1.78+.',
    diffVuln:'KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");',
    diffFix:'MLDSAKeyPairGenerator gen = new MLDSAKeyPairGenerator();\ngen.init(new MLDSAKeyGenerationParameters(new SecureRandom(), MLDSAParameters.ml_dsa_65));' },

  // ── Go ───────────────────────────────────────────────
  { lang:['go','auto'], sev:'CRITICAL', name:'Go crypto/rsa GenerateKey',
    pattern:/rsa\.GenerateKey|rsa\.GenerateMultiPrimeKey/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Go crypto/rsa — broken by quantum Shor's algorithm.",
    fix:'Use github.com/cloudflare/circl kyber768.',
    diffVuln:'privateKey, _ := rsa.GenerateKey(rand.Reader, 2048)',
    diffFix:'import "github.com/cloudflare/circl/kem/kyber/kyber768"\nscheme := kyber768.Scheme()\npk, sk, _ := scheme.GenerateKeyPair()' },

  { lang:['go','auto'], sev:'CRITICAL', name:'Go crypto/elliptic ECDH',
    pattern:/elliptic\.P256|elliptic\.P384|ecdh\.P256|ecdh\.P384/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:"Go ECDH/ECDSA — ECDLP has no quantum resistance.",
    fix:'Use circl Kyber768 for key exchange.',
    diffVuln:'curve := elliptic.P256()\npriv, _ := ecdsa.GenerateKey(curve, rand.Reader)',
    diffFix:'scheme := kyber768.Scheme()\npk, sk, _ := scheme.GenerateKeyPair()' },

  // ── C# ───────────────────────────────────────────────
  { lang:['cs','auto'], sev:'CRITICAL', name:'C# RSA.Create()',
    pattern:/RSA\.Create\s*\(|new RSACryptoServiceProvider|new RSACng/gi,
    hndl:15, qdayRisk:'HIGH',
    attack:".NET RSA broken by Shor's.",
    fix:'Use .NET 9 MLKem preview or BouncyCastle.NET.',
    diffVuln:'using var rsa = RSA.Create(2048);',
    diffFix:'using var kem = MLKem.Create(MLKemAlgorithm.MLKem768);' },

  // ── Multi-language ────────────────────────────────────
  { lang:['auto','js','py','java','go','cs','rs'], sev:'CRITICAL', name:'TLS 1.0/1.1 Configuration',
    pattern:/TLSv1\.0|TLSv1\.1|SSLv3/gi,
    hndl:10, qdayRisk:'HIGH',
    attack:'TLS 1.0/1.1 with RSA key exchange — quantum-vulnerable AND classically deprecated.',
    fix:'Enforce TLS 1.3. Enable hybrid X25519+ML-KEM-768.',
    diffVuln:"ssl_protocols TLSv1 TLSv1.1;",
    diffFix:"ssl_protocols TLSv1.3;" },

  { lang:['auto','js','py','java','go','cs','rs'], sev:'HIGH', name:'Hardcoded RSA Private Key',
    pattern:/-----BEGIN RSA PRIVATE KEY-----|-----BEGIN PRIVATE KEY-----/gi,
    hndl:15, qdayRisk:'CRITICAL',
    attack:'Hardcoded key in source is immediately harvestable. Quantum retroactive decryption applies.',
    fix:'Remove from code. Rotate the key. Use a secrets manager.',
    diffVuln:"const KEY = '-----BEGIN RSA PRIVATE KEY-----...'",
    diffFix:"const key = process.env.PRIVATE_KEY // Never hardcode" },
]

// ── Language Detection ────────────────────────────────
export const LANG_EXT_MAP: Record<string, string> = {
  '.js':'js', '.ts':'js', '.jsx':'js', '.tsx':'js',
  '.py':'py', '.java':'java', '.go':'go',
  '.cs':'cs', '.rs':'rs',
}

export function detectLang(code: string): string {
  if (/import\s+\w+\s+from|require\s*\(|const\s+\w+\s*=|=>\s*\{/.test(code)) return 'js'
  if (/def\s+\w+\s*\(|import\s+\w+|hashlib\.|cryptography\./.test(code)) return 'py'
  if (/public\s+class|import\s+java\.|KeyPairGenerator/.test(code)) return 'java'
  if (/func\s+\w+\s*\(|package\s+main|:=/.test(code)) return 'go'
  if (/using\s+System|namespace\s+\w+|public\s+static/.test(code)) return 'cs'
  if (/fn\s+\w+\s*\(|let\s+mut|use\s+\w+::/.test(code)) return 'rs'
  return 'auto'
}

// ── Core Scanner ─────────────────────────────────────
export function scanCode(code: string, lang: string, filePath?: string): ScanFinding[] {
  const lines = code.split('\n')
  const findings: ScanFinding[] = []

  for (const vuln of VULN_DB) {
    if (!vuln.lang.includes(lang) && !vuln.lang.includes('auto')) continue
    const regex = new RegExp(vuln.pattern.source, 'gi')
    let match: RegExpExecArray | null

    while ((match = regex.exec(code)) !== null) {
      const lineNum = code.substring(0, match.index).split('\n').length
      const lineText = (lines[lineNum - 1] ?? '').trim()

      if (findings.some(f => f.lineNum === lineNum && f.vuln.name === vuln.name)) continue

      findings.push({ lineNum, lineText, filePath, vuln: { ...vuln } })
    }
  }

  const sevOrder: Record<string, number> = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 }
  return findings.sort((a, b) =>
    (sevOrder[a.vuln.sev] ?? 5) - (sevOrder[b.vuln.sev] ?? 5) || a.lineNum - b.lineNum
  )
}

export function scanFile(path: string, content: string): FileScanResult {
  const ext = '.' + path.split('.').pop()!.toLowerCase()
  const lang = LANG_EXT_MAP[ext] ?? detectLang(content)
  const findings = scanCode(content, lang, path)
  return { path, lang, lineCount: content.split('\n').length, findings }
}

// ── Risk Scoring ─────────────────────────────────────
const SEV_WEIGHT: Record<string, number> = { CRITICAL: 100, HIGH: 75, MEDIUM: 40, LOW: 15 }

export function calcRiskScore(findings: ScanFinding[]): number {
  if (!findings.length) return 0
  const avg = findings.reduce((s, f) => s + (SEV_WEIGHT[f.vuln.sev] ?? 10), 0) / findings.length
  return Math.min(100, Math.round(avg))
}

export function calcHndlMax(findings: ScanFinding[]): number {
  return findings.reduce((max, f) => Math.max(max, f.vuln.hndl), 0)
}
