// lib/github/app.ts
import { App } from 'octokit'
import { createServiceClient } from '@/lib/supabase/server'
import { scanFile, calcRiskScore, calcHndlMax } from '@/lib/scan/engine'

let _app: App | null = null

export function getGithubApp(): App {
  if (!_app) {
    _app = new App({
      appId: process.env.GITHUB_APP_ID!,
      privateKey: process.env.GITHUB_APP_PRIVATE_KEY!.replace(/\\n/g, '\n'),
      webhooks: { secret: process.env.GITHUB_APP_WEBHOOK_SECRET! },
    })
  }
  return _app
}

// Get an authenticated Octokit for a specific installation
export async function getInstallationOctokit(installationId: number) {
  const app = getGithubApp()
  return app.getInstallationOctokit(installationId)
}

// Fetch all files from a repo at a given ref
export async function fetchRepoFiles(
  octokit: Awaited<ReturnType<typeof getInstallationOctokit>>,
  owner: string,
  repo: string,
  ref: string,
  maxFiles = 200
): Promise<Array<{ path: string; content: string }>> {
  const SCANNABLE = new Set(['.js','.ts','.jsx','.tsx','.py','.java','.go','.cs','.rs'])
  const SKIP = ['node_modules','vendor','dist','build','target','__pycache__','.git']

  // Get file tree
  const { data: tree } = await octokit.request('GET /repos/{owner}/{repo}/git/trees/{tree_sha}', {
    owner, repo, tree_sha: ref, recursive: '1'
  })

  const files = (tree.tree ?? [])
    .filter((f: any) => {
      if (f.type !== 'blob') return false
      if (SKIP.some(s => f.path?.includes(s + '/'))) return false
      const ext = '.' + f.path?.split('.').pop()?.toLowerCase()
      return SCANNABLE.has(ext)
    })
    .slice(0, maxFiles)

  const results: Array<{ path: string; content: string }> = []

  for (const file of files) {
    try {
      const { data } = await octokit.request('GET /repos/{owner}/{repo}/contents/{path}', {
        owner, repo, path: file.path!, ref
      })
      if ('content' in data && typeof data.content === 'string') {
        const content = Buffer.from(data.content, 'base64').toString('utf-8')
        results.push({ path: file.path!, content: content.slice(0, 200_000) })
      }
    } catch {
      // skip unreadable files
    }
  }

  return results
}

// Full scan pipeline: fetch files → scan → save to DB
export async function runRepoScan(params: {
  scanId: string
  userId: string
  repoId: string
  owner: string
  repo: string
  ref: string
  installationId: number
}) {
  const supabase = createServiceClient()

  // Update scan status to scanning
  await supabase.from('scans').update({ status: 'scanning' }).eq('id', params.scanId)

  try {
    const octokit = await getInstallationOctokit(params.installationId)
    const files = await fetchRepoFiles(octokit, params.owner, params.repo, params.ref)

    const allFindings: any[] = []
    let critCount = 0, highCount = 0, medCount = 0, lowCount = 0

    for (const file of files) {
      const result = scanFile(file.path, file.content)
      for (const f of result.findings) {
        allFindings.push({
          scan_id: params.scanId,
          user_id: params.userId,
          file_path: f.filePath ?? file.path,
          line_number: f.lineNum,
          line_text: f.lineText,
          algorithm: f.vuln.name,
          severity: f.vuln.sev,
          hndl_years: f.vuln.hndl,
          qday_risk: f.vuln.qdayRisk,
          attack_description: f.vuln.attack,
          fix_description: f.vuln.fix,
          diff_vulnerable: f.vuln.diffVuln,
          diff_fix: f.vuln.diffFix,
        })
        if (f.vuln.sev === 'CRITICAL') critCount++
        else if (f.vuln.sev === 'HIGH') highCount++
        else if (f.vuln.sev === 'MEDIUM') medCount++
        else lowCount++
      }
    }

    // Batch insert findings
    if (allFindings.length > 0) {
      await supabase.from('findings').insert(allFindings)
    }

    const riskScore = calcRiskScore(allFindings.map(f => ({
      lineNum: f.line_number, lineText: f.line_text,
      vuln: { sev: f.severity, hndl: f.hndl_years, name: f.algorithm,
              pattern: /x/, qdayRisk: f.qday_risk, attack: '', fix: '',
              diffVuln: '', diffFix: '', lang: ['auto'] }
    })))

    const hndlMax = allFindings.reduce((m, f) => Math.max(m, f.hndl_years), 0)

    // Update scan record
    await supabase.from('scans').update({
      status: 'complete',
      total_findings: allFindings.length,
      critical_count: critCount,
      high_count: highCount,
      medium_count: medCount,
      low_count: lowCount,
      risk_score: riskScore,
      hndl_max: hndlMax,
      files_scanned: files.length,
      completed_at: new Date().toISOString(),
    }).eq('id', params.scanId)

    // Update repo last_scanned_at
    await supabase.from('repos')
      .update({ last_scanned_at: new Date().toISOString() })
      .eq('id', params.repoId)

  } catch (err: any) {
    await supabase.from('scans').update({
      status: 'failed',
      error_message: err?.message ?? 'Unknown error',
      completed_at: new Date().toISOString(),
    }).eq('id', params.scanId)
    throw err
  }
}
