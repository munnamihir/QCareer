# CipherGuard — Setup Guide

## Prerequisites
- Node.js 18+
- A Supabase project
- A GitHub App
- A Stripe account

---

## 1. Clone & install

```bash
git clone https://github.com/you/cipherguard
cd cipherguard
npm install
cp .env.local.example .env.local
```

---

## 2. Supabase setup

1. Create a project at [supabase.com](https://supabase.com)
2. Go to **Settings → API** and copy:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
3. Run the migration:
```bash
npx supabase db push
# or paste supabase/migrations/001_initial_schema.sql into the SQL editor
```
4. Enable **GitHub** OAuth provider in **Authentication → Providers**
   - Callback URL: `https://your-domain.com/api/auth/callback`

---

## 3. GitHub App setup

1. Go to **GitHub Settings → Developer settings → GitHub Apps → New GitHub App**
2. Configure:
   - **Homepage URL**: `https://cipherguard.io`
   - **Webhook URL**: `https://cipherguard.io/api/github/webhook`
   - **Webhook secret**: Generate a random string → set as `GITHUB_APP_WEBHOOK_SECRET`
3. **Repository permissions**:
   - Contents: Read
   - Pull requests: Write (for PR comments)
   - Metadata: Read
4. **Subscribe to events**: Push, Pull request
5. After creating, copy **App ID** → `GITHUB_APP_ID`
6. Generate a **private key** → download the .pem file
   - Copy contents (replace newlines with `\n`) → `GITHUB_APP_PRIVATE_KEY`
7. **Install** the app on your own account for testing

---

## 4. Stripe setup

1. Create a Stripe account at [stripe.com](https://stripe.com)
2. Copy **API keys** to `.env.local`:
   - `STRIPE_SECRET_KEY` (sk_live_... or sk_test_...)
   - `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
3. Create products and prices:
```
Products → Create product → "CipherGuard Pro"
  → Add price: $49/month recurring
  → Copy Price ID → STRIPE_PRO_PRICE_ID
```
4. Set up webhook:
   - **Stripe Dashboard → Developers → Webhooks → Add endpoint**
   - Endpoint: `https://cipherguard.io/api/stripe/webhook`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`
   - Copy **Signing secret** → `STRIPE_WEBHOOK_SECRET`
5. For local testing:
```bash
npm run stripe:listen
# This forwards Stripe events to localhost:3000/api/stripe/webhook
```

---

## 5. Environment variables

Fill in `.env.local` with all values from steps 2–4.

Generate `NEXTAUTH_SECRET`:
```bash
openssl rand -base64 32
```

---

## 6. Run locally

```bash
npm run dev
# → http://localhost:3000
```

---

## 7. Deploy to Vercel

```bash
npm i -g vercel
vercel --prod
```

Then in Vercel dashboard:
- Add all environment variables from `.env.local`
- Set **Root Directory** to `/` (monorepo not used)
- Framework: **Next.js**

Update your GitHub App webhook URL and Stripe webhook URL to your production domain.

---

## Project structure

```
cipherguard/
├── app/
│   ├── (auth)/
│   │   ├── login/page.tsx          ← GitHub OAuth + magic link
│   │   └── signup/page.tsx
│   ├── (dashboard)/
│   │   ├── layout.tsx              ← Sidebar navigation
│   │   ├── dashboard/page.tsx      ← Overview + stats
│   │   ├── scan/page.tsx           ← Core scanner UI
│   │   ├── repos/page.tsx          ← GitHub repo management
│   │   ├── billing/page.tsx        ← Stripe plans + upgrade
│   │   └── settings/page.tsx
│   ├── api/
│   │   ├── auth/callback/route.ts  ← Supabase OAuth callback
│   │   ├── auth/signout/route.ts
│   │   ├── github/webhook/route.ts ← GitHub App webhook
│   │   ├── scan/route.ts           ← Scan API + AI fix streaming
│   │   └── stripe/
│   │       ├── checkout/route.ts   ← Checkout + portal sessions
│   │       └── webhook/route.ts    ← Stripe event handler
│   ├── layout.tsx
│   └── globals.css
├── lib/
│   ├── supabase/
│   │   ├── server.ts               ← Server + service role clients
│   │   └── client.ts               ← Browser client
│   ├── github/
│   │   └── app.ts                  ← GitHub App + repo scanner
│   ├── stripe/
│   │   └── index.ts                ← Stripe helpers + webhook handler
│   └── scan/
│       └── engine.ts               ← VULN_DB + scan engine (TS)
├── types/index.ts                  ← All TypeScript types + plan limits
├── middleware.ts                   ← Auth protection
└── supabase/migrations/
    └── 001_initial_schema.sql      ← Complete DB schema
```

---

## Key architectural decisions

| Decision | Reason |
|---|---|
| Next.js App Router | Server components for auth, client components for interactive scan UI |
| Supabase | Auth + Postgres RLS + real-time ready for scan progress streaming |
| GitHub App (not OAuth) | Apps can access private repos at org level without user re-auth |
| Stripe Checkout (hosted) | Fastest path to billing, handles tax/compliance automatically |
| Scan engine in TypeScript | Runs in both browser (scan page) and Node.js (repo scanner API) |
| Service role only in server | RLS protects all user data; service role only used for webhooks |

---

## Adding the first enterprise customer

1. Find target company on GitHub
2. Run: `node scripts/audit-report.js <github-org>` (build this script)
3. This generates a PDF with their public repo findings
4. Email CISO with the report attached
5. Offer a free 30-day Enterprise trial
