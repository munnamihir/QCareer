// app/api/github/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createHmac, timingSafeEqual } from 'crypto'
import { createServiceClient } from '@/lib/supabase/server'
import { runRepoScan } from '@/lib/github/app'

// Verify GitHub webhook signature
function verifySignature(payload: string, signature: string): boolean {
  const secret = process.env.GITHUB_APP_WEBHOOK_SECRET!
  const expected = 'sha256=' + createHmac('sha256', secret).update(payload).digest('hex')
  try {
    return timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
  } catch {
    return false
  }
}

export async function POST(req: NextRequest) {
  const rawBody = await req.text()
  const signature = req.headers.get('x-hub-signature-256') ?? ''
  const event = req.headers.get('x-github-event') ?? ''

  if (!verifySignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
  }

  const payload = JSON.parse(rawBody)
  const supabase = createServiceClient()

  // Handle GitHub App installation
  if (event === 'installation') {
    if (payload.action === 'created') {
      const githubUsername = payload.installation.account.login
      await supabase.from('users')
        .update({ github_installation_id: payload.installation.id })
        .eq('github_username', githubUsername)
    }
    return NextResponse.json({ ok: true })
  }

  // Handle push events — auto-scan on push to default branch
  if (event === 'push') {
    const { repository, installation, ref, after: commitSha } = payload
    if (!installation || !repository) return NextResponse.json({ ok: true })

    const defaultBranch = repository.default_branch
    const pushedBranch = ref.replace('refs/heads/', '')
    if (pushedBranch !== defaultBranch) return NextResponse.json({ ok: true })

    // Find the repo record
    const { data: repo } = await supabase
      .from('repos')
      .select('id, user_id')
      .eq('github_repo_id', repository.id)
      .single()

    if (!repo) return NextResponse.json({ ok: true })

    // Create scan record
    const { data: scan } = await supabase.from('scans').insert({
      user_id: repo.user_id,
      repo_id: repo.id,
      repo_full_name: repository.full_name,
      commit_sha: commitSha,
      branch: pushedBranch,
      status: 'pending',
      triggered_by: 'webhook',
    }).select().single()

    if (!scan) return NextResponse.json({ error: 'Failed to create scan' }, { status: 500 })

    // Run scan asynchronously (don't await — GitHub expects fast response)
    runRepoScan({
      scanId: scan.id,
      userId: repo.user_id,
      repoId: repo.id,
      owner: repository.owner.login,
      repo: repository.name,
      ref: commitSha,
      installationId: installation.id,
    }).catch(console.error)

    return NextResponse.json({ ok: true, scanId: scan.id })
  }

  return NextResponse.json({ ok: true })
}
