// app/api/scan/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { scanCode, detectLang, calcRiskScore, calcHndlMax } from '@/lib/scan/engine'
import Anthropic from '@anthropic-ai/sdk'
import { PLAN_LIMITS } from '@/types'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

// POST /api/scan — scan a code snippet and save results
export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  // Check quota
  const { data: dbUser } = await supabase
    .from('users').select('plan, scans_this_month, scans_month_reset_at').eq('id', user.id).single()
  if (!dbUser) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const limits = PLAN_LIMITS[dbUser.plan as keyof typeof PLAN_LIMITS]
  const isNewMonth = new Date() > new Date(new Date(dbUser.scans_month_reset_at).setMonth(
    new Date(dbUser.scans_month_reset_at).getMonth() + 1
  ))

  if (
    limits.scans_per_month !== -1 &&
    !isNewMonth &&
    dbUser.scans_this_month >= limits.scans_per_month
  ) {
    return NextResponse.json({ error: 'Scan limit reached. Upgrade to Pro for unlimited scans.' }, { status: 429 })
  }

  const body = await req.json()
  const { code, language, filename } = body

  if (!code || typeof code !== 'string') {
    return NextResponse.json({ error: 'code is required' }, { status: 400 })
  }

  const lang = language ?? detectLang(code)
  const findings = scanCode(code, lang, filename)
  const riskScore = calcRiskScore(findings)
  const hndlMax = calcHndlMax(findings)

  const critCount = findings.filter(f => f.vuln.sev === 'CRITICAL').length
  const highCount = findings.filter(f => f.vuln.sev === 'HIGH').length
  const medCount  = findings.filter(f => f.vuln.sev === 'MEDIUM').length
  const lowCount  = findings.filter(f => f.vuln.sev === 'LOW').length

  // Create scan record
  const { data: scan, error: scanError } = await supabase.from('scans').insert({
    user_id: user.id,
    status: 'complete',
    total_findings: findings.length,
    critical_count: critCount,
    high_count: highCount,
    medium_count: medCount,
    low_count: lowCount,
    risk_score: riskScore,
    hndl_max: hndlMax,
    files_scanned: 1,
    triggered_by: 'manual',
    completed_at: new Date().toISOString(),
  }).select().single()

  if (scanError || !scan) {
    return NextResponse.json({ error: 'Failed to create scan' }, { status: 500 })
  }

  // Insert findings
  if (findings.length > 0) {
    await supabase.from('findings').insert(findings.map(f => ({
      scan_id: scan.id,
      user_id: user.id,
      file_path: f.filePath ?? filename ?? 'untitled',
      line_number: f.lineNum,
      line_text: f.lineText,
      algorithm: f.vuln.name,
      severity: f.vuln.sev,
      hndl_years: f.vuln.hndl,
      qday_risk: f.vuln.qdayRisk,
      attack_description: f.vuln.attack,
      fix_description: f.vuln.fix,
      diff_vulnerable: f.vuln.diffVuln,
      diff_fix: f.vuln.diffFix,
    })))
  }

  // Increment usage counter
  await supabase.rpc('increment_scan_count', { p_user_id: user.id })

  return NextResponse.json({
    data: {
      scanId: scan.id,
      riskScore,
      hndlMax,
      findings: findings.length,
      critCount, highCount, medCount, lowCount,
    }
  })
}

// POST /api/scan/ai-fix — stream AI fix for a specific finding
export async function PUT(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { findingId, code, context } = await req.json()

  const { data: finding } = await supabase
    .from('findings').select('*').eq('id', findingId).eq('user_id', user.id).single()
  if (!finding) return NextResponse.json({ error: 'Finding not found' }, { status: 404 })

  const stream = await anthropic.messages.stream({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 2048,
    system: `You are a post-quantum cryptography expert specialising in NIST FIPS 203 (ML-KEM-768), FIPS 204 (ML-DSA-65), and FIPS 205 (SLH-DSA). Generate precise, drop-in code replacements. Output only the fixed code, no explanation.`,
    messages: [{
      role: 'user',
      content: `Vulnerability: ${finding.algorithm} [${finding.severity}] at line ${finding.line_number}\nContext:\n${context ?? ''}\n\nGenerate the context-aware PQC replacement preserving variable names and code style.`
    }]
  })

  const encoder = new TextEncoder()
  const readable = new ReadableStream({
    async start(controller) {
      for await (const chunk of stream) {
        if (chunk.type === 'content_block_delta' && chunk.delta.type === 'text_delta') {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text: chunk.delta.text })}\n\n`))
        }
      }
      controller.enqueue(encoder.encode('data: [DONE]\n\n'))
      controller.close()
    }
  })

  return new Response(readable, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    }
  })
}
