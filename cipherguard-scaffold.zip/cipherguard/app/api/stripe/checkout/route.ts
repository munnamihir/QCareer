// app/api/stripe/checkout/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createCheckoutSession, createPortalSession } from '@/lib/stripe'
import { z } from 'zod'

const CheckoutSchema = z.object({
  plan: z.enum(['pro', 'enterprise']),
  returnUrl: z.string().url().optional(),
})

export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const parsed = CheckoutSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
  }

  const { plan, returnUrl } = parsed.data
  const appUrl = process.env.NEXT_PUBLIC_APP_URL!

  try {
    const url = await createCheckoutSession({
      userId: user.id,
      email: user.email!,
      plan,
      returnUrl: returnUrl ?? `${appUrl}/billing`,
    })
    return NextResponse.json({ url })
  } catch (err: any) {
    console.error('Checkout error:', err)
    return NextResponse.json({ error: 'Failed to create checkout session' }, { status: 500 })
  }
}

// GET /api/stripe/checkout?portal=true — open billing portal
export async function GET(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { data: dbUser } = await supabase
    .from('users').select('stripe_customer_id').eq('id', user.id).single()

  if (!dbUser?.stripe_customer_id) {
    return NextResponse.json({ error: 'No billing account found' }, { status: 404 })
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL!
  const url = await createPortalSession(dbUser.stripe_customer_id, `${appUrl}/billing`)
  return NextResponse.json({ url })
}
