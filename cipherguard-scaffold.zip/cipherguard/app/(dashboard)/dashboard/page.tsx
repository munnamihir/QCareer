// app/(dashboard)/dashboard/page.tsx
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'

export default async function DashboardPage() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: dbUser } = await supabase
    .from('users').select('*').eq('id', user.id).single()

  // Recent scans
  const { data: recentScans } = await supabase
    .from('scans')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(5)

  // Aggregate stats
  const { data: stats } = await supabase
    .from('scans')
    .select('critical_count, high_count, medium_count, risk_score')
    .eq('user_id', user.id)
    .eq('status', 'complete')

  const totalCritical = stats?.reduce((s, r) => s + r.critical_count, 0) ?? 0
  const totalHigh     = stats?.reduce((s, r) => s + r.high_count, 0) ?? 0
  const avgRisk = stats?.length
    ? Math.round(stats.reduce((s, r) => s + r.risk_score, 0) / stats.length)
    : 0

  const plan = dbUser?.plan ?? 'free'
  const planColors: Record<string, string> = {
    free: 'bg-gray-100 text-gray-700',
    pro:  'bg-purple-100 text-purple-700',
    enterprise: 'bg-blue-100 text-blue-700',
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-500 mt-1">
            Welcome back, {dbUser?.github_username ?? user.email}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <span className={`text-xs font-medium px-3 py-1 rounded-full uppercase tracking-wide ${planColors[plan]}`}>
            {plan}
          </span>
          <Link
            href="/scan"
            className="bg-purple-600 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            New scan
          </Link>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total scans', value: stats?.length ?? 0, color: 'text-gray-900' },
          { label: 'Critical findings', value: totalCritical, color: 'text-red-600' },
          { label: 'High findings', value: totalHigh, color: 'text-orange-500' },
          { label: 'Avg risk score', value: avgRisk + '/100', color: avgRisk >= 70 ? 'text-red-600' : avgRisk >= 40 ? 'text-amber-600' : 'text-green-600' },
        ].map(({ label, value, color }) => (
          <div key={label} className="bg-white border border-gray-200 rounded-xl p-5">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">{label}</p>
            <p className={`text-3xl font-semibold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      {/* Recent scans */}
      <div className="bg-white border border-gray-200 rounded-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-sm font-semibold text-gray-800">Recent scans</h2>
          <Link href="/repos" className="text-xs text-purple-600 hover:underline">View all</Link>
        </div>
        {!recentScans?.length ? (
          <div className="px-6 py-12 text-center">
            <p className="text-gray-400 text-sm mb-4">No scans yet.</p>
            <Link href="/scan" className="text-sm text-purple-600 font-medium hover:underline">
              Run your first scan →
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {recentScans.map(scan => {
              const riskColor = scan.risk_score >= 70 ? 'text-red-600' : scan.risk_score >= 40 ? 'text-amber-500' : 'text-green-600'
              const statusColor: Record<string, string> = {
                complete: 'bg-green-50 text-green-700',
                scanning: 'bg-blue-50 text-blue-700',
                pending:  'bg-gray-50 text-gray-600',
                failed:   'bg-red-50 text-red-700',
              }
              return (
                <div key={scan.id} className="flex items-center px-6 py-4 hover:bg-gray-50 transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {scan.repo_full_name ?? 'Manual scan'}
                    </p>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {new Date(scan.created_at).toLocaleDateString()} ·{' '}
                      {scan.files_scanned} files · {scan.total_findings} findings
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`text-sm font-semibold ${riskColor}`}>
                      {scan.risk_score}/100
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor[scan.status]}`}>
                      {scan.status}
                    </span>
                    {scan.critical_count > 0 && (
                      <span className="text-xs bg-red-50 text-red-600 px-2 py-0.5 rounded-full">
                        {scan.critical_count} critical
                      </span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Upgrade banner for free users */}
      {plan === 'free' && (
        <div className="mt-6 bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-xl p-6 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-gray-900 mb-1">
              You're on the Free plan · {dbUser?.scans_this_month ?? 0}/5 scans used this month
            </p>
            <p className="text-xs text-gray-500">
              Upgrade to Pro for unlimited scans, GitHub integration, and AI auto-fix.
            </p>
          </div>
          <Link
            href="/billing"
            className="ml-4 bg-purple-600 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap"
          >
            Upgrade to Pro
          </Link>
        </div>
      )}
    </div>
  )
}
