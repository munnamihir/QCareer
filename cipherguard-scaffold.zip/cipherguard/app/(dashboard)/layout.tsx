// app/(dashboard)/layout.tsx
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { headers } from 'next/headers'

const NAV = [
  { href: '/dashboard', label: 'Dashboard',  icon: '▤' },
  { href: '/scan',      label: 'New Scan',    icon: '⬡' },
  { href: '/repos',     label: 'Repositories',icon: '⊞' },
  { href: '/billing',   label: 'Billing',     icon: '◈' },
  { href: '/settings',  label: 'Settings',    icon: '⚙' },
]

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: dbUser } = await supabase
    .from('users').select('github_username, github_avatar, plan').eq('id', user.id).single()

  const headersList = headers()
  const pathname = headersList.get('x-pathname') ?? ''

  const planBadge: Record<string, string> = {
    free: 'bg-gray-100 text-gray-500',
    pro: 'bg-purple-100 text-purple-600',
    enterprise: 'bg-blue-100 text-blue-600',
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="w-56 bg-white border-r border-gray-200 flex flex-col flex-shrink-0">
        {/* Logo */}
        <div className="px-5 py-5 border-b border-gray-100">
          <Link href="/dashboard" className="text-lg font-bold text-gray-900">
            Cipher<span className="text-purple-600">Guard</span>
          </Link>
          <span className={`ml-2 text-xs font-medium px-2 py-0.5 rounded-full ${planBadge[dbUser?.plan ?? 'free']}`}>
            {dbUser?.plan ?? 'free'}
          </span>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.map(item => {
            const active = pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${
                  active
                    ? 'bg-purple-50 text-purple-700 font-medium'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <span className="text-base">{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* User info */}
        <div className="px-4 py-4 border-t border-gray-100">
          <div className="flex items-center gap-2.5">
            {dbUser?.github_avatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={dbUser.github_avatar} alt="" className="w-7 h-7 rounded-full" />
            ) : (
              <div className="w-7 h-7 rounded-full bg-purple-100 flex items-center justify-center text-xs font-medium text-purple-600">
                {(dbUser?.github_username ?? user.email ?? 'U')[0].toUpperCase()}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-800 truncate">
                {dbUser?.github_username ?? user.email}
              </p>
            </div>
          </div>
          <form action="/api/auth/signout" method="POST">
            <button className="mt-3 text-xs text-gray-400 hover:text-gray-600 w-full text-left">
              Sign out
            </button>
          </form>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  )
}
