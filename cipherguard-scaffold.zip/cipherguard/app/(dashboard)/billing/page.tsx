'use client'
// app/(dashboard)/billing/page.tsx
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'

type Plan = 'free' | 'pro' | 'enterprise'

const PLANS = [
  {
    id: 'free' as Plan,
    name: 'Free',
    price: '$0',
    period: 'forever',
    features: ['5 scans / month', 'Single file + ZIP up to 10MB', 'All 25+ vuln patterns', 'Export .md report', '10 AI messages'],
    cta: 'Current plan',
    disabled: true,
  },
  {
    id: 'pro' as Plan,
    name: 'Pro',
    price: '$49',
    period: '/month per seat',
    features: ['Unlimited scans', 'GitHub repo sync', 'AI auto-fix + rewrite', 'CI/CD GitHub Action', 'Unlimited AI chat', 'Migration PDF reports'],
    cta: 'Upgrade to Pro',
    disabled: false,
    featured: true,
  },
  {
    id: 'enterprise' as Plan,
    name: 'Enterprise',
    price: 'Custom',
    period: 'annual contract',
    features: ['Everything in Pro', 'Org-wide dashboard', 'CBOM + compliance reports', 'Slack + Jira integration', 'SSO + audit logs', 'Dedicated SLA support'],
    cta: 'Contact sales',
    disabled: false,
  },
]

export default function BillingPage() {
  const [currentPlan, setCurrentPlan] = useState<Plan>('free')
  const [loading, setLoading] = useState(false)
  const [loadingPlan, setLoadingPlan] = useState<Plan | null>(null)

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return
      supabase.from('users').select('plan').eq('id', user.id).single()
        .then(({ data }) => { if (data) setCurrentPlan(data.plan as Plan) })
    })

    // Handle ?upgraded=true from Stripe redirect
    const params = new URLSearchParams(window.location.search)
    if (params.get('upgraded') === 'true') {
      window.history.replaceState({}, '', '/billing')
    }
  }, [])

  const handleUpgrade = async (plan: Plan) => {
    if (plan === 'enterprise') {
      window.location.href = 'mailto:hello@cipherguard.io?subject=Enterprise inquiry'
      return
    }
    setLoadingPlan(plan)
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan, returnUrl: window.location.href }),
      })
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch (err) {
      console.error(err)
    } finally {
      setLoadingPlan(null)
    }
  }

  const handleManageBilling = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/stripe/checkout')
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch {}
    setLoading(false)
  }

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Billing & Plans</h1>
        <p className="text-sm text-gray-500 mt-1">
          You are on the <span className="font-medium text-purple-600 capitalize">{currentPlan}</span> plan.
          {currentPlan !== 'free' && (
            <button
              onClick={handleManageBilling}
              disabled={loading}
              className="ml-3 text-sm text-gray-500 underline hover:text-gray-700"
            >
              {loading ? 'Opening...' : 'Manage billing →'}
            </button>
          )}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {PLANS.map(plan => (
          <div
            key={plan.id}
            className={`relative bg-white rounded-2xl p-6 flex flex-col ${
              plan.featured
                ? 'border-2 border-purple-500 shadow-lg shadow-purple-100'
                : 'border border-gray-200'
            }`}
          >
            {plan.featured && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="bg-purple-600 text-white text-xs font-medium px-3 py-1 rounded-full">
                  Most popular
                </span>
              </div>
            )}

            <div className="mb-5">
              <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-1">{plan.name}</p>
              <p className="text-3xl font-bold text-gray-900">{plan.price}</p>
              <p className="text-xs text-gray-400 mt-0.5">{plan.period}</p>
            </div>

            <ul className="space-y-2.5 flex-1 mb-6">
              {plan.features.map(f => (
                <li key={f} className="flex items-start gap-2 text-sm text-gray-600">
                  <span className="text-green-500 font-bold mt-0.5">✓</span>
                  {f}
                </li>
              ))}
            </ul>

            {currentPlan === plan.id ? (
              <div className="w-full text-center text-sm font-medium text-gray-400 border border-gray-200 rounded-xl py-2.5">
                Current plan
              </div>
            ) : (
              <button
                onClick={() => handleUpgrade(plan.id)}
                disabled={plan.disabled || loadingPlan === plan.id}
                className={`w-full text-sm font-medium py-2.5 rounded-xl transition-colors ${
                  plan.featured
                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                    : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {loadingPlan === plan.id ? 'Redirecting...' : plan.cta}
              </button>
            )}
          </div>
        ))}
      </div>

      <p className="text-center text-xs text-gray-400 mt-8">
        Payments are processed securely by Stripe. Cancel anytime. No setup fees.
      </p>
    </div>
  )
}
