'use client'
// app/(dashboard)/scan/page.tsx
import { useState, useRef, useCallback } from 'react'
import { scanCode, detectLang, calcRiskScore, calcHndlMax, LANG_EXT_MAP } from '@/lib/scan/engine'
import type { ScanFinding } from '@/types'

const SEV_COLOR: Record<string, string> = {
  CRITICAL: 'text-red-600 bg-red-50 border-red-200',
  HIGH:     'text-orange-600 bg-orange-50 border-orange-200',
  MEDIUM:   'text-amber-600 bg-amber-50 border-amber-200',
  LOW:      'text-green-600 bg-green-50 border-green-200',
}

export default function ScanPage() {
  const [code, setCode]           = useState('')
  const [lang, setLang]           = useState('auto')
  const [findings, setFindings]   = useState<ScanFinding[]>([])
  const [scanned, setScanned]     = useState(false)
  const [saving, setSaving]       = useState(false)
  const [openIdx, setOpenIdx]     = useState<number | null>(null)
  const [lineCount, setLineCount] = useState(1)
  const textareaRef               = useRef<HTMLTextAreaElement>(null)
  const lineNumRef                = useRef<HTMLDivElement>(null)

  const onInput = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value
    setCode(val)
    setLineCount(val.split('\n').length)
    if (lang === 'auto') {
      // language will be detected on scan
    }
  }, [lang])

  const syncScroll = useCallback(() => {
    if (lineNumRef.current && textareaRef.current) {
      lineNumRef.current.scrollTop = textareaRef.current.scrollTop
    }
  }, [])

  const runScan = useCallback(async () => {
    if (!code.trim()) return
    const detectedLang = lang === 'auto' ? detectLang(code) : lang
    const results = scanCode(code, detectedLang)
    setFindings(results)
    setScanned(true)
    setOpenIdx(null)

    // Save to DB
    setSaving(true)
    try {
      await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language: detectedLang }),
      })
    } catch {}
    setSaving(false)
  }, [code, lang])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const ext = '.' + file.name.split('.').pop()!.toLowerCase()
    const detLang = LANG_EXT_MAP[ext] ?? 'auto'
    setLang(detLang)
    const reader = new FileReader()
    reader.onload = ev => {
      const content = ev.target?.result as string
      setCode(content)
      setLineCount(content.split('\n').length)
    }
    reader.readAsText(file)
  }

  const riskScore = scanned ? calcRiskScore(findings) : 0
  const hndlMax   = scanned ? calcHndlMax(findings) : 0
  const riskColor = riskScore >= 70 ? 'text-red-600' : riskScore >= 40 ? 'text-amber-500' : 'text-green-600'

  const lines = Array.from({ length: lineCount }, (_, i) => i + 1)
  const vulnLines = new Set(findings.map(f => f.lineNum))

  return (
    <div className="h-[calc(100vh-56px)] grid grid-cols-2 divide-x divide-gray-200">
      {/* Left: Editor */}
      <div className="flex flex-col">
        <div className="flex items-center gap-3 px-4 py-2.5 border-b border-gray-200 bg-gray-50">
          <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Code Input</span>
          <select
            value={lang}
            onChange={e => setLang(e.target.value)}
            className="ml-auto text-xs border border-gray-200 rounded px-2 py-1 bg-white text-gray-700"
          >
            <option value="auto">Auto-detect</option>
            <option value="js">JavaScript / TypeScript</option>
            <option value="py">Python</option>
            <option value="java">Java</option>
            <option value="go">Go</option>
            <option value="cs">C# / .NET</option>
            <option value="rs">Rust</option>
          </select>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Line numbers */}
          <div
            ref={lineNumRef}
            className="bg-gray-50 border-r border-gray-100 overflow-y-hidden select-none w-10 flex-shrink-0"
            style={{ fontFamily: 'monospace', fontSize: 12, lineHeight: '24px', paddingTop: 8 }}
          >
            {lines.map(n => (
              <div
                key={n}
                className={`text-right pr-2 ${vulnLines.has(n) ? 'text-red-500 font-semibold' : 'text-gray-300'}`}
              >
                {n}
              </div>
            ))}
          </div>
          {/* Textarea */}
          <textarea
            ref={textareaRef}
            value={code}
            onChange={onInput}
            onScroll={syncScroll}
            spellCheck={false}
            placeholder="Paste your code here, or upload a file below..."
            className="flex-1 resize-none outline-none p-2 font-mono text-xs text-gray-800 bg-white overflow-auto"
            style={{ lineHeight: '24px' }}
          />
        </div>

        <div className="flex items-center gap-2 px-4 py-2 border-t border-gray-200 bg-gray-50">
          <button
            onClick={runScan}
            className="bg-purple-600 text-white text-xs font-medium px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            ⬡ Scan
          </button>
          <label className="cursor-pointer text-xs font-medium text-gray-600 border border-gray-200 rounded-lg px-3 py-2 hover:bg-gray-100 transition-colors">
            ↑ Upload file
            <input type="file" className="hidden" accept=".js,.ts,.py,.java,.go,.cs,.rs" onChange={handleFileUpload} />
          </label>
          <button onClick={() => { setCode(''); setFindings([]); setScanned(false); setLineCount(1) }}
            className="text-xs text-gray-400 hover:text-gray-600 ml-auto">
            Clear
          </button>
          <span className="text-xs text-gray-400">{lineCount} lines</span>
        </div>
      </div>

      {/* Right: Results */}
      <div className="flex flex-col overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-2.5 border-b border-gray-200 bg-gray-50">
          <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">
            Vulnerability Report
          </span>
          {scanned && (
            <span className="ml-auto text-xs text-gray-400">
              {saving ? 'Saving...' : findings.length + ' findings'}
            </span>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {!scanned ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-3">
              <div className="text-4xl opacity-20">⬡</div>
              <p className="text-sm text-gray-400">Paste code and click Scan</p>
              <p className="text-xs text-gray-300">Checks for RSA, ECDH, ECDSA, MD5, SHA-1 and more</p>
            </div>
          ) : (
            <>
              {/* Score card */}
              <div className="flex items-center gap-4 border border-gray-200 rounded-xl p-4 mb-4 bg-white">
                <div className="text-center">
                  <p className={`text-4xl font-bold ${riskColor}`}>{riskScore}</p>
                  <p className="text-xs text-gray-400 uppercase tracking-wide mt-0.5">Risk score</p>
                </div>
                <div className="flex-1 text-sm space-y-1">
                  <p className="text-gray-700 font-medium">
                    {riskScore >= 70 ? 'Critical risk' : riskScore >= 40 ? 'High risk' : findings.length ? 'Moderate risk' : 'Clean ✓'}
                  </p>
                  <p className="text-gray-400 text-xs">
                    {findings.length} findings · Max HNDL: {hndlMax} years · Data exposed until ~{2026 + hndlMax}
                  </p>
                  <div className="flex gap-2 mt-2">
                    {(['CRITICAL','HIGH','MEDIUM','LOW'] as const).map(s => {
                      const cnt = findings.filter(f => f.vuln.sev === s).length
                      if (!cnt) return null
                      return (
                        <span key={s} className={`text-xs px-2 py-0.5 rounded-full border ${SEV_COLOR[s]}`}>
                          {cnt} {s.toLowerCase()}
                        </span>
                      )
                    })}
                  </div>
                </div>
              </div>

              {findings.length === 0 && (
                <div className="text-center py-10 text-gray-400 text-sm">
                  No quantum vulnerabilities detected ✓
                </div>
              )}

              {/* Finding cards */}
              {findings.map((f, i) => (
                <div key={i} className={`border rounded-xl mb-3 overflow-hidden border-l-4 ${
                  f.vuln.sev === 'CRITICAL' ? 'border-l-red-500 border-gray-200' :
                  f.vuln.sev === 'HIGH'     ? 'border-l-orange-400 border-gray-200' :
                  f.vuln.sev === 'MEDIUM'   ? 'border-l-amber-400 border-gray-200' :
                                              'border-l-green-400 border-gray-200'
                }`}>
                  <button
                    onClick={() => setOpenIdx(openIdx === i ? null : i)}
                    className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                  >
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded border ${SEV_COLOR[f.vuln.sev]}`}>
                      {f.vuln.sev}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{f.vuln.name}</p>
                      <p className="text-xs text-gray-400 truncate">
                        Line {f.lineNum} · <code className="text-amber-600">{f.lineText.slice(0,60)}</code>
                      </p>
                    </div>
                    <span className="text-gray-300 text-xs">{openIdx === i ? '▲' : '▼'}</span>
                  </button>

                  {openIdx === i && (
                    <div className="px-4 pb-4 space-y-3 border-t border-gray-100">
                      <div className="flex gap-3 pt-3">
                        {[
                          ['HNDL', f.vuln.hndl + ' yr'],
                          ['Q-Day', f.vuln.qdayRisk],
                          ['Exposed until', '~' + (2026 + f.vuln.hndl)],
                        ].map(([k, v]) => (
                          <div key={k} className="bg-gray-50 rounded-lg px-3 py-2 text-center">
                            <p className="text-sm font-semibold text-gray-800">{v}</p>
                            <p className="text-xs text-gray-400 uppercase tracking-wide">{k}</p>
                          </div>
                        ))}
                      </div>
                      <div>
                        <p className="text-xs font-medium text-red-600 mb-1">Attack</p>
                        <p className="text-xs text-gray-600 leading-relaxed">{f.vuln.attack}</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-green-600 mb-1">Fix</p>
                        <p className="text-xs text-gray-600 leading-relaxed">{f.vuln.fix}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400 uppercase tracking-wide mb-2">PQC replacement</p>
                        <pre className="text-xs bg-gray-900 text-green-400 rounded-lg p-3 overflow-x-auto whitespace-pre-wrap">
                          {f.vuln.diffFix}
                        </pre>
                        <button
                          onClick={() => navigator.clipboard.writeText(f.vuln.diffFix)}
                          className="mt-2 text-xs text-purple-600 hover:underline"
                        >
                          Copy fix
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
