// app/layout.tsx
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'CipherGuard — Quantum Vulnerability Scanner',
  description: 'Find and fix quantum-vulnerable cryptography across your entire codebase. AI-powered migration to NIST FIPS 203/204/205 PQC standards.',
  keywords: ['post-quantum', 'cryptography', 'PQC', 'NIST', 'security', 'RSA', 'quantum vulnerability'],
  openGraph: {
    title: 'CipherGuard',
    description: 'AI-powered post-quantum cryptography migration platform',
    url: 'https://cipherguard.io',
    siteName: 'CipherGuard',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
